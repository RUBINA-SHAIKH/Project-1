package com.onlineshopping.app.exception;
public class InvalidRequestException extends RuntimeException 
{

	private static final long serialVersionUID = 1L;

	public InvalidRequestException(RuntimeException string) {
        super(string);
    }

    public InvalidRequestException(String message, Throwable cause)
    {
        super(message,cause);
}
}

