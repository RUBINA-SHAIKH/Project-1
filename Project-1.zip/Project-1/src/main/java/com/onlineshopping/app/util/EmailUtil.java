package com.onlineshopping.app.util;

import org.springframework.stereotype.Component;

@Component
public class EmailUtil {

    // Method to send an email notification
    public void sendEmail(String recipient, String subject, String content) {
        // Implement the logic to send an email using a third-party email service or library
        // ...
        System.out.println("Email sent to: " + recipient);
        System.out.println("Subject: " + subject);
        System.out.println("Content: " + content);
    }

    // Other utility methods for email operations
}

