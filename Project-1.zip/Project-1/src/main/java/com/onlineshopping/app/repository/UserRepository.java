package com.onlineshopping.app.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineshopping.app.controller.UserDTO;
import com.onlineshopping.app.model.User;

public interface UserRepository extends JpaRepository<User, Long>
{

    // Custom query method to find a user by email
    User findByEmail(String email);

	Optional<User> findByUsername(String username);
    @Override
	<S extends User>List<S> saveAll(Iterable<S> userDTO);

	<S> UserDTO getById(Iterable<S> userDTO);

    // Other custom query methods for user-related operations
}
