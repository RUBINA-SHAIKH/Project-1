package com.onlineshopping.app.dto;

import antlr.collections.List;

public class OrderDTO 
{
    @SuppressWarnings("unused")
	private Long id;
    @SuppressWarnings("unused")
	private String customerName;
    @SuppressWarnings("unused")
	private List plants;
    @SuppressWarnings("unused")
	private String status;

    // Constructors, getters, and setters

    // Other methods as needed



	public Object getStatus() {
		return null;
	}

}
