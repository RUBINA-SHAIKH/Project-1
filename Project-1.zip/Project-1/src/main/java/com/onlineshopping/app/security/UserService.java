package com.onlineshopping.app.security;

public interface UserService {

}
