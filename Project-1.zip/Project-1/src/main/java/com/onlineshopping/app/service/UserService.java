package com.onlineshopping.app.service;

import java.util.Collections;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.onlineshopping.app.controller.UserDTO;
import com.onlineshopping.app.exception.ResourceNotFoundException;
import com.onlineshopping.app.model.User;
import com.onlineshopping.app.repository.UserRepository;
import com.onlineshopping.app.security.UserDetailsService;

@Service
public class UserService implements UserDetailsService 
{
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        // Implement the logic to retrieve user details and return a UserDetails object
        // ...

        return new org.springframework.security.core.userdetails.User(
                user.getName(),
                user.getPassword(),
                // Set user roles or authorities here
                Collections.emptyList()
        );
    }

    // Method to register a new user
    @SuppressWarnings("unchecked")
	public <S> UserDTO registerUser(UserDTO userDTO) {
        // Implement the logic to validate and save the user
        // ...

        return userRepository.getById((Iterable<S>) userDTO);
    }

    // Method to retrieve user details by ID
    public User getUserById(Long userId) {
        return userRepository.findById(userId)
        .orElseThrow();
    }

    // Method to update user information
    public User updateUser(User updatedUser) {
        User user = userRepository.findById(updatedUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + updatedUser.getId()));

        // Implement the logic to update user information
        // ...

        return userRepository.save(user);
    }

	public UserDTO loginUser(UserDTO userDTO) {
		return null;
	}

	public UserDTO updateUserProfile(Long id, UserDTO userDTO) {
		return null;
	}

    // Other methods as needed
}


