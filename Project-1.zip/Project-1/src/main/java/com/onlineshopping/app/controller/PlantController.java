package com.onlineshopping.app.controller;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineshopping.app.dto.PlantDTO;
import com.onlineshopping.app.model.Plant;
import com.onlineshopping.app.service.PlantService;

@RestController
@RequestMapping("/plants")
public class PlantController {
    private final PlantService plantService;

    public PlantController(PlantService plantService) {
        this.plantService = plantService;
    }

    // Endpoint to retrieve all plants
    @GetMapping
    public ResponseEntity<List<PlantDTO>> getAllPlants() {
        List<PlantDTO> plants = plantService.getAllPlants();
        return new ResponseEntity<>(plants, HttpStatus.OK);
    }

    // Endpoint to retrieve a specific plant by its ID
    @GetMapping("/{id}")
    public ResponseEntity<Plant> getPlantById(@PathVariable Long id) {
        Plant plant = plantService.getPlantById(id);
        return new ResponseEntity<Plant>(plant, HttpStatus.OK);
    }

    // Endpoint to add a new plant
    @PostMapping
    public ResponseEntity<Plant> addPlant(@RequestBody PlantDTO plantDTO) {
        Plant createdPlant = plantService.addPlant(plantDTO);
        return new ResponseEntity<Plant>(createdPlant, HttpStatus.CREATED);
    }

    // Endpoint to update an existing plant
    @PutMapping("/{id}")
    public ResponseEntity<PlantDTO> updatePlant(@PathVariable Long id, @RequestBody PlantDTO plantDTO) {
        PlantDTO updatedPlant = plantService.updatePlant(id, plantDTO);
        return new ResponseEntity<>(updatedPlant, HttpStatus.OK);
    }

    // Endpoint to delete a plant by its ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlant(@PathVariable Long id) {
        plantService.deletePlant(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
}
}
