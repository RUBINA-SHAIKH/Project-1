package com.onlineshopping.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineshopping.app.model.Order;

import antlr.collections.List;

public interface OrderRepository extends JpaRepository<Order, Long> {

    // Custom query method to find orders by customer ID
    List findByCustomerId(Long customerId);

    // Other custom query methods for order-related operations
}

