package com.onlineshopping.app.controller;

public class UserDTO {

}
