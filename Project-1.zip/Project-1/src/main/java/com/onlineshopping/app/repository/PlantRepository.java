package com.onlineshopping.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineshopping.app.dto.PlantDTO;
import com.onlineshopping.app.model.Plant;

import antlr.collections.List;

public interface PlantRepository extends JpaRepository<Plant, Long> {

    // Custom query method to find plants by category
    List findByCategory(String category);

	Plant save(PlantDTO plantDTO);

    // Other custom query methods for plant-related operations
}