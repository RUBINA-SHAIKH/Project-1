package com.onlineshopping.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.onlineshopping.app.dto.PlantDTO;
import com.onlineshopping.app.exception.ResourceNotFoundException;
import com.onlineshopping.app.model.Plant;
import com.onlineshopping.app.repository.PlantRepository;

@Service
public class PlantService {
    private final PlantRepository plantRepository;

    public PlantService(PlantRepository plantRepository) {
        this.plantRepository = plantRepository;
    }

    // Method to add a new plant
    public Plant addPlant(PlantDTO plantDTO) {
        // Implement the logic to validate and save the plant
        // ...

        return plantRepository.save(plantDTO);
    }

    // Method to update plant information
    public Plant updatePlant(Plant updatedPlant) {
        Plant plant = plantRepository.findById(updatedPlant.getId())
                .orElseThrow();

        // Implement the logic to update plant information
        // ...

        return plantRepository.save(plant);
    }

    // Method to retrieve details of a plant by ID
    public Plant getPlantById(Long plantId) {
        return plantRepository.findById(plantId)
                .orElseThrow(() -> new ResourceNotFoundException("Plant not found with ID: " + plantId));
    }

    // Method to delete a plant
    public void deletePlant(Long plantId) {
        if (!plantRepository.existsById(plantId)) {
            throw new ResourceNotFoundException("Plant not found with ID: " + plantId);
        }

        plantRepository.deleteById(plantId);
    }

	public List<PlantDTO> getAllPlants() {
		return null;
	}

	public PlantDTO updatePlant(Long id, PlantDTO plantDTO) {
		return null;
	}

    // Other methods as needed
}


