package com.onlineshopping.app.dto;
import java.math.BigDecimal;
public class PlantDTO
{
    
	@SuppressWarnings("unused")
	private Long id;
    @SuppressWarnings("unused")
	private String name;
    @SuppressWarnings("unused")
	private String category;
    @SuppressWarnings("unused")
	private String description;
    @SuppressWarnings("unused")
	private BigDecimal price;

    // Constructors, getters, and setters

    // Other methods as needed
}

