package com.onlineshopping.app.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

@Component
public class DateUtil {

    // Method to get the current date and time
    public LocalDateTime getCurrentDateTime() {
        return LocalDateTime.now();
    }

    // Method to format a LocalDateTime object to a specific date-time format
    public String formatDateTime(LocalDateTime dateTime, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return dateTime.format(formatter);
    }

    // Other utility methods for date and time operations
}


