package com.onlineshopping.app.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public interface UserDetailsService extends UserService
{

	UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;
}
