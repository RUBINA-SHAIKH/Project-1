package com.onlineshopping.app.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ResourceNotFoundExceptionTest2 {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
