package com.onlineshopping.app.exception;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InvalidRequestExceptionTest {

    @Test
    public void testConstructorWithMessage() {
        String errorMessage = "Invalid request";
        InvalidRequestException exception = new InvalidRequestException(errorMessage, null);
        assertEquals(errorMessage, exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String errorMessage = "Invalid request";
        Throwable cause = new IllegalArgumentException("Invalid argument");
        InvalidRequestException exception = new InvalidRequestException(errorMessage, cause);
        assertEquals(errorMessage, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithCause() {
        IllegalArgumentException cause = new IllegalArgumentException("Invalid argument");
        InvalidRequestException exception = new InvalidRequestException(cause);
        assertEquals(cause, exception.getCause());
}
}

