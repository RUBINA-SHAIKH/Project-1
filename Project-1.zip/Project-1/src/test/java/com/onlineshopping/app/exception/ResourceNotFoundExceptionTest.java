package com.onlineshopping.app.exception;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ResourceNotFoundExceptionTest {

    @Test
    public void testConstructorWithMessage() {
        String errorMessage = "Resource not found";
        ResourceNotFoundException exception = new ResourceNotFoundException(errorMessage);
        assertEquals(errorMessage, exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String errorMessage = "Resource not found";
        Throwable cause = new RuntimeException("Internal server error");
        ResourceNotFoundException exception = new ResourceNotFoundException(errorMessage, cause);
        assertEquals(errorMessage, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithCause() {
        Throwable cause = new RuntimeException("Internal server error");
        ResourceNotFoundException exception = new ResourceNotFoundException(cause);
        assertEquals(cause, exception.getCause());
}
}
